//
//  ViewController.swift
//  Settings
//
//  Created by Antonio Adrian Chavez on 5/23/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var icons = [[""], ["AirplaneMode", "WiFi", "Bluetooth", "CellularData"], ["NotificationCenter", "Sounds", "DND", "ScreenTime"], ["General", "ControlCenter", "Display", "Accessibility", "Wallpaper", "Siri", "TouchID", "SOS", "BatteryUsage", "Privacy"], ["AppStore", "Wallet"], ["KeychainSync", "Mail", "Contacts", "Calendar", "Notes", "Reminders", "Voice Memos", "Photo", "Messages", "FaceTime", "Maps", "Compass", "Measure", "Safari", "News", "Stocks", "Health", "Shortcuts"], ["Music", "TV", "Photos", "Camera", "Books", "Podcasts", "Game Center"], ["VideoSubscriber"]]
       
       var TitleStg = [[""], ["Airplane Mode", "Wi-Fi", "Bluetooth", "CellularData"], ["Notification Center", "Sounds & Haptics", "Do Not Distrub", "Screen Time"], ["General", "ControlCenter", "Display & Brightness", "Accessibility", "Wallpaper", "Siri", "TouchID & Passcode", "Emergency SOS", "Battery", "Privacy"], ["iTunes & App Store", "Wallet & Apple Pay"], ["Password & Accounts", "Mail", "Contacts", "Calendar", "Notes", "Reminders", "Voice Memos", "Photo", "Messages", "FaceTime", "Maps", "Compass", "Measure", "Safari", "News", "Stocks", "Health", "Shortcuts"], ["Music", "TV", "Photos", "Camera", "Books", "Podcasts", "Game Center"], ["TV Provider"]]
      
       
       var footertitleStg = [ [""], ["", "Sumannua's Wi-Fi", "On", ""], ["", "", "", ""], ["", "", "", "", "=", "", "", "", "", ""], ["", ""], ["", "=", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""], ["", "", "", "", "", "", ""], ["XomxAR XZDINRY"]]
       
    
       
           var countsCells = [ [" "], [" ", " ", " ", " "], [" ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " " , " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " "], [" "]]
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "Setting"
        self.navigationController?.navigationBar.prefersLargeTitles = true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 14 {
            
            return 47
            
        } else if indexPath.row == 13 {
            
            return 47
            
        } else if indexPath.row == 12 {
            
            return 47
            
        } else if indexPath.row == 11 {
           
            return 15
            
            
        } else if indexPath.row == 10 {
            
            return 47
            
        } else if indexPath.row == 9 {
            
            return 47
            
        } else if indexPath.row == 8 {
            
            return 47
            
        } else if indexPath.row == 7 {
            
            return 47
            
        } else if indexPath.row == 6 {
            
            return 15
            
        } else if indexPath.row == 5 {
            
            return 47
            
        } else if indexPath.row == 4 {
            
            return 47
            
        } else if indexPath.row == 3 {
            
            return 47
            
        } else if indexPath.row == 2 {
            
            return 47
            
        } else if indexPath.row == 1 {
           
            return 15
            
        } else {
            
            return 85
            
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       var iCloudCells: iCloudTableViewCell!
                 
        var cells: CellsTableViewCell!
              
        var footerCells: FooterCellsTableViewCell!
              
        var enableCells: EnableCellsTableViewCell!
       
        var spaceCells: SpaceTableViewCell!
                 
                 
        if indexPath.row == 18 {
                    
                    cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                        
                        cells.IconsIMG.image = UIImage(named: "Siri")
                        
                        cells.IconsName.text = "Siri & Search"
                    
                        return cells!
                     
                
        } else if indexPath.row == 17 {
            
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "Wallpaper")
                
                cells.IconsName.text = "Wallpaper"
            
                return cells!
            
            
        } else if indexPath.row == 16 {
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "Accessibility")
                
                cells.IconsName.text = "Accessibility"
            
                return cells!
            
        } else if indexPath.row == 15 {
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "Display")
                
                cells.IconsName.text = "Display & Brightness"
            
                return cells!
            
            
        } else if indexPath.row == 14 {
                    
              cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                  
                  cells.IconsIMG.image = UIImage(named: "ControlCenter")
                  
                  cells.IconsName.text = "Control Center"
              
                  return cells!
        
        } else if indexPath.row == 12 {
                    
              cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                  
                  cells.IconsIMG.image = UIImage(named: "General")
                  
                  cells.IconsName.text = "General"
              
                  return cells!
        
          } else if indexPath.row == 11 {
                    
              spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
              
              
              return spaceCells!
        
          } else if indexPath.row == 10 {
                      
                cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                    
                    cells.IconsIMG.image = UIImage(named: "ScreenTime")
                    
                    cells.IconsName.text = "Screen Time"
                
                    return cells!
          
            } else if indexPath.row == 9 {
                        
                 cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                      
                      cells.IconsIMG.image = UIImage(named: "DND")
                      
                      cells.IconsName.text = "Do Not Distrub"
                  
                      return cells!
                  
            
              } else if indexPath.row == 8 {
                          
                   cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                        
                        cells.IconsIMG.image = UIImage(named: "Sounds")
                        
                        cells.IconsName.text = "Sounds & Haptics"
                    
                        return cells!
              
                } else if indexPath.row == 7 {
                            
                     cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                          
                          cells.IconsIMG.image = UIImage(named: "NotificationCenter")
                          
                          cells.IconsName.text = "Notification Center"
                      
                          return cells!
                
                  } else if indexPath.row == 6 {
                    
              spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
              
              
              return spaceCells!
        
          } else if indexPath.row == 5 {
                      
                 cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                                       
                cells.IconsIMG.image = UIImage(named: "CellularData")
                                       
                cells.IconsName.text = "Cellular"
                                   
                                      
                 return cells!
                             
          
            } else if indexPath.row == 4 {
                        
                  footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                                 
                             
                    footerCells?.IconsIMG?.image = UIImage(named: "Bluetooth")
                                 
                            
                    footerCells.IconsLBL.text = "Bluetooth"
                  footerCells.IconsFooter.text = "On"
                            
                    return footerCells!
            
              }  else if indexPath.row == 3 {
                    
              footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                           
                       
              footerCells?.IconsIMG?.image = UIImage(named: "WiFi")
                           
                      
            footerCells.IconsLBL.text = "Wi-Fi"
            footerCells.IconsFooter.text = "Sumannua's Wi-Fi"
                      
              return footerCells!
        
          } else if indexPath.row == 2 {
                  
            enableCells = tableView.dequeueReusableCell(withIdentifier: "EnableCells", for: indexPath) as? EnableCellsTableViewCell
                         
                     
            enableCells?.IconsIMG?.image = UIImage(named: "AirplaneMode")
                         
                    
            enableCells.IconsName.text = "Airplane Mode"

                    
            return enableCells!
      
        } else if indexPath.row == 1 {
                    
                      
                    spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
                         
                         
                         return spaceCells!
                     
                     
                 }  else {
                     
                    iCloudCells = tableView.dequeueReusableCell(withIdentifier: "iCloudCells", for: indexPath) as? iCloudTableViewCell
                     
                     iCloudCells.IMG.image = UIImage(named: "Untitled 28")
                     iCloudCells.NameLBL.text = "Antonio Adrian Chavez"
                     
                     return iCloudCells!
                     
                 }
                   

            
        }
    
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 18
   

        
    }
    
    
    
    
}
