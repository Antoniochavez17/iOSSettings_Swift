//
//  iCloudTableViewCell.swift
//  Settings
//
//  Created by Antonio Adrian Chavez on 5/23/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class iCloudTableViewCell: UITableViewCell {

    @IBOutlet weak var IMG: UIImageView!
    @IBOutlet weak var NameLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
