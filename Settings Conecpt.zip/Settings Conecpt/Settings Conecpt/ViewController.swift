//
//  ViewController.swift
//  Settings Conecpt
//
//  Created by Antonio Adrian Chavez on 6/21/22.
//

import UIKit

class ViewController: UITableViewController, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    
    struct Object {
        var seactionName: String!
        var seactionObjection: [String]!
        var icon: [String]
        var Detext: [String]!
    }
    
    
    var objectArray = [Object]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        objectArray = [
            
            
            Object(seactionName: "", seactionObjection: [""], icon: ["clear"], Detext: [""]),
            
            Object(seactionName: "", seactionObjection: [
                "Airplane Mode",
                "Wi-Fi",
                "Bluetooth",
                "Cellular"
                 ], icon: [
                    "AirplaneMode",
                    "WiFi",
                    "Bluetooth",
                    "CellularData"], Detext: [
                    "", "Sumannua's Wi-Fi",
                    "On",
                    "On"
                    ]),
            
            Object(seactionName: "", seactionObjection: ["Notification Center", "Sounds & Haptics", "Do Not Distrub", "Screen Time"], icon: ["NotificationCenter", "Sounds", "DND", "ScreenTime"], Detext: ["", "", "On", "On"]),
            
            Object(seactionName: "", seactionObjection: ["General", "Control Center", "Display & Brightness", "Accessibility", "Wallpaper", "Siri", "TouchID & Passcode", "Emergency SOS", "Battery", "Privacy"], icon: ["General", "ControlCenter", "Display", "Accessibility", "Wallpaper", "Siri", "TouchID", "SOS", "BatteryUsage", "Privacy"], Detext: ["", "", "", "", "", "", "", "", "", ""]),
            
            Object(seactionName: "", seactionObjection: ["AppStore", "Wallet"], icon: ["iTunes & App Store", "Wallet & Apple Pay"], Detext: ["", ""]),
            
            Object(seactionName: "", seactionObjection: ["Password & Accounts", "Mail", "Contacts", "Calendar", "Notes", "Reminders", "Voice Memos", "Photo", "Messages", "FaceTime", "Maps", "Compass", "Measure", "Safari", "News", "Stocks", "Health", "Shortcuts"], icon: ["KeychainSync", "Mail", "Contacts", "Calendar", "Notes", "Reminders", "Voice Memos", "Photo", "Messages", "FaceTime", "Maps", "Compass", "Measure", "Safari", "News", "Stocks", "Health", "Shortcuts"], Detext: ["", "=", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]),
            
            Object(seactionName: "", seactionObjection: ["Music", "TV", "Photos", "Camera", "Books", "Podcasts", "Game Center"], icon: ["Music", "TV", "Photos", "Camera", "Books", "Podcasts", "Game Center"], Detext: ["", "", "", "", "", "", ""]),
            
            
        ]
        
        
        
        
        tableView = UITableView(frame: .zero, style: .insetGrouped)
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 60, bottom: 0, right: 0)
        
        self.navigationItem.title = "Settings"
        self.navigationController?.navigationBar.prefersLargeTitles = true
        
        self.navigationController?.navigationItem.largeTitleDisplayMode = .never
                  
        UINavigationBar.appearance().isTranslucent = false
        
        let app = UINavigationBarAppearance()
             
        let navigationBar = self.navigationController?.navigationBar
              
        app.backgroundColor = .clear
        app.configureWithOpaqueBackground()
        app.titleTextAttributes = [.foregroundColor: UIColor.label]
        app.largeTitleTextAttributes = [.foregroundColor: UIColor.label]
        app.backgroundColor = .systemGroupedBackground
        
        self.navigationController?.navigationBar.scrollEdgeAppearance = app
                  
                
        navigationBar!.standardAppearance = app
        navigationBar!.scrollEdgeAppearance = app
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return objectArray.count
        
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch section {
    case 0:
            
                let layout = UICollectionViewFlowLayout()
                layout.estimatedItemSize = CGSize(width: 150, height: 150)
                layout.scrollDirection = .horizontal
                
                let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
                collectionView.delegate = self
                collectionView.dataSource = self
                collectionView.register(CollectionBoxView.self, forCellWithReuseIdentifier: "cell")
                collectionView.showsHorizontalScrollIndicator = false
                return collectionView
        
    default:
        
        return nil
        
    }
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
        return 383 - 210 + 10
        } else {
            return 15
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objectArray[section].seactionObjection.count
        
    }
    

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.value1, reuseIdentifier: "Slice List")
        
        let cellImg = UIImageView()
        cellImg.frame = CGRect(x: 17, y: 9, width: 27, height: 27)
        
    
        cellImg.image = UIImage(named: objectArray[indexPath.section].icon[indexPath.row])

        let yInt = 5
        if indexPath.section == 0 {
            
            let ProfilecellImg = UIImageView()
            let profileName = UILabel()
            let profileDetext = UILabel()
            
            ProfilecellImg.frame = CGRect(x: 13 + 4, y: 12 - yInt, width: 60, height: 60)
            ProfilecellImg.image = UIImage(named: "Profile")
            ProfilecellImg.layer.cornerRadius = 30
            ProfilecellImg.layer.masksToBounds = true
            
            profileName.frame = CGRect(x: 81, y: 16 - 2 - yInt, width: 211, height: 36)
            profileName.text = "  Antonio Adrian Chavez"
            
            profileDetext.frame = CGRect(x: 81, y: 48 - 2 - yInt, width: 211, height: 17)
            profileDetext.textColor = .systemGray
            profileDetext.text = "  Apple ID Mannage"
            
            let sizeNum = 1
            profileName.font = UIFont.systemFont(ofSize: CGFloat(18 + sizeNum))
            profileDetext.font = UIFont.systemFont(ofSize: CGFloat(13 + sizeNum) )
            
        
            
            cell.addSubview(ProfilecellImg)
            cell.addSubview(profileDetext)
            cell.addSubview(profileName)
        }
        
        if indexPath.section == 1 {
            
            if indexPath.row == 0 {
                let switchDisplay: UISwitch = {
                    let switchs = UISwitch(frame: CGRect(x: 0, y: 0, width: 220, height: 20))
                    switchs.isOn = false
                    return switchs
                }()
                
                cell.accessoryView = switchDisplay
                
            }
        }
        
        
        print(objectArray[indexPath.section].icon[indexPath.row])
        
        cellImg.layer.cornerRadius = 5
        cellImg.layer.masksToBounds = true
    
        cell.accessoryType = .disclosureIndicator
        
        cell.addSubview(cellImg)
        
        
        cell.textLabel?.text = objectArray[indexPath.section].seactionObjection[indexPath.row]
    
        cell.detailTextLabel?.text = objectArray[indexPath.section].Detext[indexPath.row]
    
      
        
        cell.textLabel?.numberOfLines = 0
        cell.backgroundColor = .secondarySystemGroupedBackground
        
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.section == 0 {
            
            return 75
            
        } else {
            return 47
        }
    
    }
    
    // MARK: UICollectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        10
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionBoxView
    
        switch indexPath.section {
        case 0:
            
            cell.labelText = "General"
            cell.detailText = "\nStatus: \nInternet Connected \nName: Sumannua's WI-Fi \nSignal: 75%"
            
//            cell.detailText = "\n"
            cell.processView?.isHidden = false
            cell.processView?.progress = 0.55
            cell.processView?.progressTintColor = .systemYellow
            cell.iconsView = UIImage(named: "General")
            
        default:
            
            let addLabel = UILabel()
        
            let imageAttachment = NSTextAttachment()
            
            imageAttachment.image = UIImage(systemName: "plus.app.fill")?.withTintColor(.systemGray)
            
            let fullString = NSMutableAttributedString(string: "")
            fullString.append(NSAttributedString(attachment: imageAttachment))
            addLabel.frame = CGRect(x: 6, y: 8, width: 149, height: 113)
            addLabel.numberOfLines = 0
            addLabel.textAlignment = .center
            addLabel.attributedText = fullString
            
            cell.addSubview(addLabel)
            
        }
        
        return cell
    }
}

func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    
    return CGSize(width: 170, height: 131)
    
}

func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
    
    return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
    
}


class CollectionBoxView: UICollectionViewCell {
  
    var background = UIView()
    var detailText: String?
    var iconsView: UIImage?
    var labelText: String?
    var processView: UIProgressView?

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: Note for ANTONIO
    /// This is where you can make uiview inside the collection view cell below here.
    override func layoutSubviews() {
        super.layoutSubviews()
        background.removeFromSuperview()
        background.translatesAutoresizingMaskIntoConstraints = false
        background.backgroundColor = .secondarySystemBackground
        background.layer.cornerRadius = 13
        background.layer.cornerCurve = .continuous
        self.addSubview(background)
        background.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        background.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        background.heightAnchor.constraint(equalToConstant: 140).isActive = true
        background.widthAnchor.constraint(equalToConstant: 145).isActive = true
        
        processView?.frame = CGRect(x: 6, y: 42, width: 150, height: 2)
        
        
        let collectiontextLabel = UILabel()
        collectiontextLabel.text = labelText
        collectiontextLabel.frame = CGRect(x: 41, y: 10, width: 114, height: 22)
        let collectiondetailText = UILabel()
        collectiondetailText.frame = CGRect(x: 8, y: 40, width: 148, height: 81)
        collectiondetailText.text = detailText
        collectiondetailText.font = UIFont.systemFont(ofSize: 13)
        collectiondetailText.textColor = .systemGray
        collectiondetailText.numberOfLines = 0
        let collectionimageView = UIImageView()
        collectionimageView.image = iconsView
        collectionimageView.frame = CGRect(x: 8, y: 8, width: 26, height: 26)
   
       
        background.addSubview(collectiontextLabel)
        background.addSubview(collectiondetailText)
//        background.addSubview(processView!)
        background.addSubview(collectionimageView)
        
        
    }
}

